package dostupsite

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
