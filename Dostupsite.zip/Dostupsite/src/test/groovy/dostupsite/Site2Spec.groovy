package dostupsite

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class Site2Spec extends Specification implements DomainUnitTest<Site2> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
