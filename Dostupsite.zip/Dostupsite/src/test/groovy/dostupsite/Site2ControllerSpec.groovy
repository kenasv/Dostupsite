package dostupsite

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class Site2ControllerSpec extends Specification implements ControllerUnitTest<Site2Controller> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
