package dostupsite

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class Site1Spec extends Specification implements DomainUnitTest<Site1> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
